plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.nawaboud.pro"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.nawaboud.pro"
        minSdk = 24
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
