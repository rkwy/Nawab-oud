package com.nawaboud.pro

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var printBusy = false
    private var shareBusy = false

    inner class AndroidBridge {
        @JavascriptInterface
        fun printPage() {
            runOnUiThread {
                if (printBusy) return@runOnUiThread
                printBusy = true
                try {
                    val printManager = getSystemService(Context.PRINT_SERVICE) as android.print.PrintManager
                    printManager.print(
                        "Nawab Oud Receipt",
                        web.createPrintDocumentAdapter("Nawab Oud Receipt"),
                        android.print.PrintAttributes.Builder().build()
                    )
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Print failed: ${e.message}", Toast.LENGTH_SHORT).show()
                } finally {
                    web.postDelayed({ printBusy = false }, 1200)
                }
            }
        }

        @JavascriptInterface
        fun shareReceiptPdf() {
            runOnUiThread {
                if (shareBusy) return@runOnUiThread
                shareBusy = true
                try {
                    createAndShareReceiptPdf()
                } finally {
                    web.postDelayed({ shareBusy = false }, 1200)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AndroidBridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    private fun createAndShareReceiptPdf() {
        // Render only the receipt at the same 58mm layout width used for printing.
        web.evaluateJavascript(
            """(function(){
                document.documentElement.classList.add('share-receipt-only');
                var e=document.querySelector('.receipt-border');
                return e ? e.scrollHeight : 0;
            })()"""
        ) { _ ->
            val oldWidth = web.width.coerceAtLeast(1)
            val oldHeight = web.height.coerceAtLeast(1)
            val targetWidth = 576
            val pdfWidth = 164 // approximately 58mm at 72dpi

            try {
                // Give the receipt a deterministic layout width first, then measure its
                // actual rendered height. This prevents the WebView viewport/controls
                // from being included in the shared PDF.
                web.measure(
                    android.view.View.MeasureSpec.makeMeasureSpec(targetWidth, android.view.View.MeasureSpec.EXACTLY),
                    android.view.View.MeasureSpec.makeMeasureSpec(20000, android.view.View.MeasureSpec.AT_MOST)
                )
                web.layout(0, 0, targetWidth, web.measuredHeight.coerceAtLeast(400))

                web.evaluateJavascript(
                    """(function(){ var e=document.querySelector('.receipt-border'); return e ? e.scrollHeight : document.body.scrollHeight; })()"""
                ) { heightResult ->
                    val contentHeight = heightResult.replace("\"", "").toFloatOrNull()?.coerceAtLeast(400f) ?: web.measuredHeight.toFloat()
                    val targetHeight = contentHeight.toInt().coerceAtLeast(400)
                    web.measure(
                        android.view.View.MeasureSpec.makeMeasureSpec(targetWidth, android.view.View.MeasureSpec.EXACTLY),
                        android.view.View.MeasureSpec.makeMeasureSpec(targetHeight, android.view.View.MeasureSpec.EXACTLY)
                    )
                    web.layout(0, 0, targetWidth, targetHeight)

                    val pdfHeight = (targetHeight * pdfWidth / targetWidth.toFloat()).toInt().coerceAtLeast(400)
                    val pdf = PdfDocument()
                    val pageInfo = PdfDocument.PageInfo.Builder(pdfWidth, pdfHeight, 1).create()
                    val page = pdf.startPage(pageInfo)
                    val canvas: Canvas = page.canvas
                    canvas.drawColor(Color.WHITE)
                    canvas.save()
                    canvas.scale(pdfWidth.toFloat() / targetWidth.toFloat(), pdfWidth.toFloat() / targetWidth.toFloat())
                    web.draw(canvas)
                    canvas.restore()
                    pdf.finishPage(page)

                    val dir = File(cacheDir, "receipts")
                    dir.mkdirs()
                    val file = File(dir, "Nawab-Oud-Receipt-${System.currentTimeMillis()}.pdf")
                    FileOutputStream(file).use { pdf.writeTo(it) }
                    pdf.close()
                    shareFile(file, "application/pdf")

                    // Restore the normal screen only after the PDF/share file exists.
                    web.evaluateJavascript("document.documentElement.classList.remove('share-receipt-only');", null)
                    web.measure(
                        android.view.View.MeasureSpec.makeMeasureSpec(oldWidth, android.view.View.MeasureSpec.EXACTLY),
                        android.view.View.MeasureSpec.makeMeasureSpec(oldHeight, android.view.View.MeasureSpec.EXACTLY)
                    )
                    web.layout(0, 0, oldWidth, oldHeight)
                }
            } catch (e: Exception) {
                web.evaluateJavascript("document.documentElement.classList.remove('share-receipt-only');", null)
                Toast.makeText(this@MainActivity, "Couldn't prepare receipt: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun shareFile(file: File, mime: String) {
        val uri: Uri = androidx.core.content.FileProvider.getUriForFile(
            this,
            "${BuildConfig.APPLICATION_ID}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share / Print receipt"))
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
