package com.nawaboud.pro

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var printBusy = false
    private var shareBusy = false

    inner class AndroidBridge {
        @JavascriptInterface
        fun printPage() {
            runOnUiThread {
                if (printBusy) return@runOnUiThread
                printBusy = true
                try {
                    val printManager = getSystemService(Context.PRINT_SERVICE) as android.print.PrintManager
                    printManager.print(
                        "Nawab Oud Receipt",
                        web.createPrintDocumentAdapter("Nawab Oud Receipt"),
                        android.print.PrintAttributes.Builder().build()
                    )
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Print failed: ${e.message}", Toast.LENGTH_SHORT).show()
                } finally {
                    web.postDelayed({ printBusy = false }, 1200)
                }
            }
        }

        @JavascriptInterface
        fun shareReceiptPdf() {
            runOnUiThread {
                if (shareBusy) return@runOnUiThread
                shareBusy = true
                try {
                    createAndShareReceiptPdf()
                } finally {
                    web.postDelayed({ shareBusy = false }, 1200)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AndroidBridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    private fun createAndShareReceiptPdf() {
        // Share the same receipt content as the PDF/print version — never the
        // surrounding WebView controls (Back / Share / Print).
        web.evaluateJavascript(
            """(function(){
                document.documentElement.classList.add('share-receipt-only');
                var e=document.querySelector('.receipt-border');
                return e ? e.scrollHeight : document.body.scrollHeight;
            })()"""
        ) { result ->
            val cssHeight = result.replace("\"", "").toFloatOrNull()?.coerceAtLeast(400f) ?: 1000f
            val oldWidth = web.width
            val oldHeight = web.height
            val targetWidth = 576
            val targetHeight = (cssHeight * targetWidth / web.width.coerceAtLeast(1).toFloat()).toInt().coerceAtLeast(400)
            val pdfWidth = 164 // ~58mm at 72dpi
            val pdfHeight = (targetHeight * pdfWidth / targetWidth.toFloat()).toInt().coerceAtLeast(400)

            try {
                web.measure(
                    android.view.View.MeasureSpec.makeMeasureSpec(targetWidth, android.view.View.MeasureSpec.EXACTLY),
                    android.view.View.MeasureSpec.makeMeasureSpec(targetHeight, android.view.View.MeasureSpec.EXACTLY)
                )
                web.layout(0, 0, targetWidth, targetHeight)

                val pdf = PdfDocument()
                val pageInfo = PdfDocument.PageInfo.Builder(pdfWidth, pdfHeight, 1).create()
                val page = pdf.startPage(pageInfo)
                val canvas: Canvas = page.canvas
                canvas.drawColor(Color.WHITE)
                val drawScale = pdfWidth.toFloat() / targetWidth.toFloat()
                canvas.save()
                canvas.scale(drawScale, drawScale)
                web.draw(canvas)
                canvas.restore()
                pdf.finishPage(page)

                val dir = File(cacheDir, "receipts")
                dir.mkdirs()
                val file = File(dir, "Nawab-Oud-Receipt-${System.currentTimeMillis()}.pdf")
                FileOutputStream(file).use { pdf.writeTo(it) }
                pdf.close()
                shareFile(file, "application/pdf")
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Couldn't prepare receipt: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                // Restore the normal on-screen receipt after the PDF is created.
                web.evaluateJavascript("document.documentElement.classList.remove('share-receipt-only');", null)
                web.measure(
                    android.view.View.MeasureSpec.makeMeasureSpec(oldWidth.coerceAtLeast(1), android.view.View.MeasureSpec.EXACTLY),
                    android.view.View.MeasureSpec.makeMeasureSpec(oldHeight.coerceAtLeast(1), android.view.View.MeasureSpec.EXACTLY)
                )
                web.layout(0, 0, oldWidth.coerceAtLeast(1), oldHeight.coerceAtLeast(1))
            }
        }
    }

    private fun shareFile(file: File, mime: String) {
        val uri: Uri = androidx.core.content.FileProvider.getUriForFile(
            this,
            "${BuildConfig.APPLICATION_ID}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share / Print receipt"))
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
