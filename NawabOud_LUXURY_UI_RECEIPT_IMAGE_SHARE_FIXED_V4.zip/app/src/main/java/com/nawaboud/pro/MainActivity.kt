package com.nawaboud.pro

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.graphics.Picture
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.view.View
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var exportBusy = false

    inner class AndroidBridge {
        @JavascriptInterface fun printPage() = runOnUiThread {
            try {
                val pm = getSystemService(Context.PRINT_SERVICE) as android.print.PrintManager
                pm.print("Nawab Oud Receipt", web.createPrintDocumentAdapter("Nawab Oud Receipt"), android.print.PrintAttributes.Builder().build())
            } catch (e: Exception) { toast("Print failed: ${e.message}") }
        }
        @JavascriptInterface fun shareReceiptPdf() = runOnUiThread { exportReceipt(Mode.SHARE_PDF) }
        @JavascriptInterface fun saveReceiptPdf() = runOnUiThread { exportReceipt(Mode.SAVE_PDF) }
        @JavascriptInterface fun saveReceiptImage() = runOnUiThread { exportReceipt(Mode.SAVE_IMAGE) }
        @JavascriptInterface fun shareReceiptImage() = runOnUiThread { exportReceipt(Mode.SHARE_IMAGE) }
    }

    private enum class Mode { SHARE_PDF, SAVE_PDF, SAVE_IMAGE, SHARE_IMAGE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.useWideViewPort = false
        web.settings.loadWithOverviewMode = false
        web.setInitialScale(100)
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AndroidBridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    private fun exportReceipt(mode: Mode) {
        if (exportBusy) return
        exportBusy = true
        web.evaluateJavascript("document.documentElement.classList.add('share-receipt-only');void(0)") {
            web.postDelayed({
                val oldW = web.width.coerceAtLeast(1)
                val oldH = web.height.coerceAtLeast(1)
                val targetW = 576
                try {
                    // Put the receipt into an isolated, fixed-width WebView layout.
                    web.measure(ViewMeasure.exact(targetW), ViewMeasure.atMost(20000))
                    web.layout(0, 0, targetW, web.measuredHeight.coerceAtLeast(1))
                    web.scrollTo(0, 0)

                    // capturePicture captures the WebView page at its laid-out content size.
                    // Unlike web.draw(canvas), it avoids device-viewport scaling/cropping.
                    val picture = web.capturePicture()
                    val pw = picture.width.coerceAtLeast(1)
                    val ph = picture.height.coerceAtLeast(1)
                    val outH = kotlin.math.ceil(ph * targetW.toFloat() / pw.toFloat()).toInt().coerceAtLeast(1)
                    val bitmap = Bitmap.createBitmap(targetW, outH, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(bitmap)
                    canvas.drawColor(Color.WHITE)
                    canvas.scale(targetW.toFloat() / pw.toFloat(), outH.toFloat() / ph.toFloat())
                    picture.draw(canvas)

                    when (mode) {
                        Mode.SAVE_IMAGE, Mode.SHARE_IMAGE -> {
                            val dir = File(cacheDir, "receipts").also { it.mkdirs() }
                            val png = File(dir, "Nawab-Oud-Bill-${System.currentTimeMillis()}.png")
                            FileOutputStream(png).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                            if (mode == Mode.SAVE_IMAGE) saveToDownloads(png, "Nawab-Oud-Bill.png", "image/png")
                            else shareFile(png, "image/png")
                        }
                        Mode.SHARE_PDF, Mode.SAVE_PDF -> {
                            // Build the PDF from the same correctly rendered receipt bitmap,
                            // so PDF and PNG have identical framing/content.
                            val pdfW = 164
                            val pdfH = kotlin.math.ceil(outH * pdfW.toFloat() / targetW.toFloat()).toInt().coerceAtLeast(1)
                            val pdf = PdfDocument()
                            val page = pdf.startPage(PdfDocument.PageInfo.Builder(pdfW, pdfH, 1).create())
                            page.canvas.drawColor(Color.WHITE)
                            page.canvas.drawBitmap(bitmap, null,
                                android.graphics.Rect(0, 0, pdfW, pdfH), null)
                            pdf.finishPage(page)
                            val dir = File(cacheDir, "receipts").also { it.mkdirs() }
                            val f = File(dir, "Nawab-Oud-Bill-${System.currentTimeMillis()}.pdf")
                            FileOutputStream(f).use { pdf.writeTo(it) }
                            pdf.close()
                            if (mode == Mode.SAVE_PDF) saveToDownloads(f, "Nawab-Oud-Bill.pdf", "application/pdf")
                            else shareFile(f, "application/pdf")
                        }
                    }
                    bitmap.recycle()
                } catch (e: Exception) {
                    toast("Couldn't prepare bill: ${e.message}")
                } finally {
                    restoreWeb(oldW, oldH)
                }
            }, 180)
        }
    }

    private object ViewMeasure {
        fun exact(v:Int)=android.view.View.MeasureSpec.makeMeasureSpec(v, android.view.View.MeasureSpec.EXACTLY)
        fun atMost(v:Int)=android.view.View.MeasureSpec.makeMeasureSpec(v, android.view.View.MeasureSpec.AT_MOST)
    }

    private fun restoreWeb(w:Int,h:Int){
        web.evaluateJavascript("document.documentElement.classList.remove('share-receipt-only');", null)
        web.measure(ViewMeasure.exact(w), ViewMeasure.exact(h)); web.layout(0,0,w,h)
        web.postDelayed({ exportBusy=false },300)
    }

    private fun shareFile(file: File, mime: String) {
        val uri = FileProvider.getUriForFile(this, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply { type=mime; putExtra(Intent.EXTRA_STREAM,uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        startActivity(Intent.createChooser(intent, "Share Nawab Oud bill"))
    }

    private fun saveToDownloads(file: File, name: String, mime: String) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Nawab Oud")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw Exception("Could not create download")
                contentResolver.openOutputStream(uri).use { out -> file.inputStream().use { it.copyTo(out!!) } }
                values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0); contentResolver.update(uri, values, null, null)
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).resolve("Nawab Oud"); dir.mkdirs()
                file.copyTo(dir.resolve(name), overwrite=true)
            }
            toast("Saved to Downloads/Nawab Oud")
        } catch (e: Exception) { toast("Save failed: ${e.message}") }
    }

    private fun toast(s:String)=runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
}
