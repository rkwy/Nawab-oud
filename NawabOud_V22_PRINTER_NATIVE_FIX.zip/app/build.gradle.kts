plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.nawaboud.pro"
    compileSdk = 35
    buildFeatures {
        buildConfig = true
    }

    defaultConfig {
        applicationId = "com.nawaboud.pro"
        minSdk = 24
        targetSdk = 35
        versionCode = 4
        versionName = "4.0"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
