package com.nawaboud.billing;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class MainActivity extends android.app.Activity {
    private WebView webView;
    private boolean exporting = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.BLACK);
        requestHighRefreshRate();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.TRANSPARENT);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= 29) s.setForceDark(WebSettings.FORCE_DARK_OFF);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        setContentView(webView);
        if (Build.VERSION.SDK_INT >= 35) webView.setRequestedFrameRate(120f);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void requestHighRefreshRate() {
        try {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.preferredRefreshRate = 120f;
            getWindow().setAttributes(lp);
        } catch (Throwable ignored) { }
        if (Build.VERSION.SDK_INT >= 35) {
            try { webViewRequestedFrameRate(); } catch (Throwable ignored) { }
        }
    }

    private void webViewRequestedFrameRate() {
        if (webView != null) webView.setRequestedFrameRate(120f);
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("typeof closeReceipt==='function' ? (closeReceipt(), 'closed') : 'no-receipt'", null);
        }
    }

    private class AndroidBridge {
        @JavascriptInterface public void saveReceiptPdf() { exportReceipt(false, true); }
        @JavascriptInterface public void shareReceiptPdf() { exportReceipt(true, true); }
        @JavascriptInterface public void saveReceiptImage() { exportReceipt(false, false); }
        @JavascriptInterface public void shareReceiptImage() { exportReceipt(true, false); }
        @JavascriptInterface public void printPage() {
            runOnUiThread(() -> {
                if (webView == null) return;
                webView.evaluateJavascript("document.documentElement.classList.add('export-mode');document.documentElement.style.setProperty('--export-w','384px');document.getElementById('app').style.display='none';document.getElementById('pro').style.display='none';document.body.style.background='#fff';'ok'", v -> {
                    Toast.makeText(MainActivity.this, "Preparing receipt for printing…", Toast.LENGTH_SHORT).show();
                    webView.postDelayed(() -> {
                        android.print.PrintManager pm = (android.print.PrintManager) getSystemService(Context.PRINT_SERVICE);
                        android.print.PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter("Nawab-Oud-Receipt");
                        pm.print("Nawab Oud Receipt", adapter, new android.print.PrintAttributes.Builder()
                                .setMediaSize(android.print.PrintAttributes.MediaSize.UNKNOWN_PORTRAIT)
                                .setMinMargins(android.print.PrintAttributes.Margins.NO_MARGINS).build());
                        restorePage();
                    }, 250);
                });
            });
        }
    }

    private void exportReceipt(boolean share, boolean pdf) {
        if (exporting) return;
        exporting = true;
        runOnUiThread(() -> webView.evaluateJavascript(
                "(function(){document.documentElement.classList.add('export-mode');document.documentElement.style.setProperty('--export-w','768px');document.getElementById('app').style.display='none';document.getElementById('pro').style.display='none';document.body.style.background='#fff';window.scrollTo(0,0);return document.body.scrollHeight;})()",
                value -> webView.postDelayed(() -> {
                    try {
                        int height = Math.max(500, parseJsInt(value));
                        height = Math.min(height, 12000);
                        Bitmap bitmap = renderWebView(768, height);
                        if (pdf) {
                            File file = writePdf(bitmap);
                            if (share) shareFile(file, "application/pdf", "Nawab Oud Receipt");
                            else Toast.makeText(this, "PDF saved", Toast.LENGTH_SHORT).show();
                        } else {
                            Uri uri = savePng(bitmap);
                            if (share) shareUri(uri, "image/png", "Nawab Oud Receipt");
                            else Toast.makeText(this, "Image saved", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Throwable t) {
                        Toast.makeText(this, "Export failed", Toast.LENGTH_SHORT).show();
                    } finally {
                        restorePage();
                        exporting = false;
                    }
                }, 280)));
    }

    private int parseJsInt(String value) {
        try { return Integer.parseInt(value.replaceAll("[^0-9]", "")); }
        catch (Exception e) { return 3000; }
    }

    private Bitmap renderWebView(int width, int height) {
        webView.measure(View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY));
        webView.layout(0, 0, width, height);
        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.WHITE);
        webView.draw(canvas);
        return bitmap;
    }

    private void restorePage() {
        runOnUiThread(() -> {
            if (webView == null) return;
            webView.evaluateJavascript("document.documentElement.classList.remove('export-mode');document.getElementById('app').style.display='';document.getElementById('pro').style.display='';document.body.style.background='';window.scrollTo(0,0);'restored'", null);
            webView.postDelayed(() -> {
                webView.requestLayout();
                if (Build.VERSION.SDK_INT >= 35) webView.setRequestedFrameRate(120f);
            }, 80);
        });
    }

    private File writePdf(Bitmap bitmap) throws IOException {
        File dir = new File(getCacheDir(), "shared");
        if (!dir.exists()) dir.mkdirs();
        File file = new File(dir, "Nawab-Oud-Receipt.pdf");
        PdfDocument doc = new PdfDocument();
        int pageWidth = 164;
        int pageHeight = Math.max(220, Math.round(pageWidth * bitmap.getHeight() / (float) bitmap.getWidth()));
        PdfDocument.Page page = doc.startPage(new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create());
        page.getCanvas().drawBitmap(bitmap, null, new android.graphics.Rect(0,0,pageWidth,pageHeight), null);
        doc.finishPage(page);
        try (FileOutputStream out = new FileOutputStream(file)) { doc.writeTo(out); }
        doc.close();
        return file;
    }

    private Uri savePng(Bitmap bitmap) throws IOException {
        String name = "Nawab-Oud-Receipt-" + System.currentTimeMillis() + ".png";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Nawab Oud");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IOException("MediaStore insert failed");
            try (OutputStream out = getContentResolver().openOutputStream(uri)) { bitmap.compress(Bitmap.CompressFormat.PNG, 100, out); }
            return uri;
        }
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Nawab Oud");
        if (!dir.exists()) dir.mkdirs();
        File file = new File(dir, name);
        try (FileOutputStream out = new FileOutputStream(file)) { bitmap.compress(Bitmap.CompressFormat.PNG, 100, out); }
        return Uri.fromFile(file);
    }

    private void shareFile(File file, String mime, String title) {
        Uri uri = FileProvider.getUriForFile(this, "com.nawaboud.billing.fileprovider", file);
        shareUri(uri, mime, title);
    }

    private void shareUri(Uri uri, String mime, String title) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, title));
    }
}
