package com.nawaboud.pro

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var printBusy = false
    private var shareBusy = false

    inner class AndroidBridge {
        @JavascriptInterface
        fun printPage() {
            runOnUiThread {
                if (printBusy) return@runOnUiThread
                printBusy = true
                try {
                    val printManager = getSystemService(Context.PRINT_SERVICE) as android.print.PrintManager
                    printManager.print(
                        "Nawab Oud Receipt",
                        web.createPrintDocumentAdapter("Nawab Oud Receipt"),
                        android.print.PrintAttributes.Builder().build()
                    )
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Print failed: ${e.message}", Toast.LENGTH_SHORT).show()
                } finally {
                    web.postDelayed({ printBusy = false }, 1200)
                }
            }
        }

        @JavascriptInterface
        fun shareReceiptPdf() {
            runOnUiThread {
                if (shareBusy) return@runOnUiThread
                shareBusy = true
                try {
                    createAndShareReceiptPdf()
                } finally {
                    web.postDelayed({ shareBusy = false }, 1200)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AndroidBridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    private fun createAndShareReceiptPdf() {
        // Generate the PDF from the receipt area only. The share-only class must
        // remain applied until the asynchronous WebView measurement/draw finishes.
        web.evaluateJavascript(
            """(function(){
                document.documentElement.classList.add('share-receipt-only');
                var e=document.querySelector('#printArea .receipt-border') || document.querySelector('.receipt-border');
                return JSON.stringify({
                    width: e ? e.scrollWidth : document.body.scrollWidth,
                    height: e ? e.scrollHeight : document.body.scrollHeight
                });
            })()"""
        ) { result ->
            try {
                val json = result.trim()
                val widthMatch = Regex("""\\"width\\":(\d+(?:\.\d+)?)""").find(json)
                val heightMatch = Regex("""\\"height\\":(\d+(?:\.\d+)?)""").find(json)
                val contentWidth = widthMatch?.groupValues?.get(1)?.toFloatOrNull()?.coerceAtLeast(1f) ?: 576f
                val contentHeight = heightMatch?.groupValues?.get(1)?.toFloatOrNull()?.coerceAtLeast(400f) ?: 1000f

                // 58mm thermal width represented at 203dpi (~464px). Use a
                // compact PDF page with the receipt's aspect ratio.
                val pdfWidth = 164
                val targetWidth = 576
                val targetHeight = (contentHeight * targetWidth / contentWidth).toInt().coerceAtLeast(400)
                val pdfHeight = (targetHeight * pdfWidth / targetWidth.toFloat()).toInt().coerceAtLeast(400)

                web.measure(
                    android.view.View.MeasureSpec.makeMeasureSpec(targetWidth, android.view.View.MeasureSpec.EXACTLY),
                    android.view.View.MeasureSpec.makeMeasureSpec(targetHeight, android.view.View.MeasureSpec.EXACTLY)
                )
                web.layout(0, 0, targetWidth, targetHeight)

                val pdf = PdfDocument()
                val pageInfo = PdfDocument.PageInfo.Builder(pdfWidth, pdfHeight, 1).create()
                val page = pdf.startPage(pageInfo)
                page.canvas.drawColor(Color.WHITE)
                val drawScale = pdfWidth.toFloat() / targetWidth.toFloat()
                page.canvas.save()
                page.canvas.scale(drawScale, drawScale)
                web.draw(page.canvas)
                page.canvas.restore()
                pdf.finishPage(page)

                val dir = File(cacheDir, "receipts")
                dir.mkdirs()
                val file = File(dir, "Nawab-Oud-Receipt-${System.currentTimeMillis()}.pdf")
                FileOutputStream(file).use { pdf.writeTo(it) }
                pdf.close()
                shareFile(file, "application/pdf")
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Couldn't prepare receipt: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                // This runs only after the asynchronous callback has completed,
                // so the PDF contains no Back/Share/Print controls.
                web.evaluateJavascript("document.documentElement.classList.remove('share-receipt-only');", null)
            }
        }
    }

    private fun shareFile(file: File, mime: String) {
        val uri: Uri = androidx.core.content.FileProvider.getUriForFile(
            this,
            "${BuildConfig.APPLICATION_ID}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share / Print receipt"))
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
