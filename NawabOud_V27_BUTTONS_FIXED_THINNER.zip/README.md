# Nawab Oud Pro v3

Offline Android billing/POS app for Nawab Oud.

Included:
- Attar and perfume billing with the bundled product list
- Bottle/size options including Golden/Fancy, Crystal and Luxury bottles
- Crystal 3ml fixed total pricing and ₹1000 bottle charge for Crystal 6ml+ / Luxury bottles
- Attar and perfume Buy 2 Get 1 offers with the lowest-priced item free
- ₹ amount and percentage discounts
- Golden/Fancy 6ml bottle discount
- Saved bill history with View/Print
- Daily/monthly sales reports
- Local stock tracking and adjustment
- JSON backup/restore
- Premium receipt layout with 58mm thermal-print CSS
- Android system print and receipt PDF sharing
- Nawab Oud launcher icon
- Perfume fragrance selection with 30ml / 50ml / 100ml sizes
- Premium perfume pricing for LV Ombre Nomade, Black Oud and Tom Ford Oud Wood
- Duplicate-tap protection and one-way bill-finalization logic to prevent UI freezing/repeated bills
- AndroidX + BuildConfig enabled

The project is configured for GitHub Actions and Gradle 8.11.1.


Receipt updated to match the approved light reference design; app icon retained.


## Automatic mixed offers
- 1 attar + 1 perfume: one attar is free.
- 2 × 30ml perfumes + 1 × 6ml attar: the 6ml attar is free.
- Existing selectable 2+1 offers remain available.


## V27 button/export repair
- Receipt action buttons are wired once after the receipt is rendered; duplicate inline + document handlers were removed.
- Touch/click handling uses the receipt action container with `passive:false` for Android WebView reliability.
- Android bridge methods remain dedicated for Save PDF, Share PDF, Save Image, Share Image, and Print.
- Added the missing luxury CSS file inside `app/src/main/assets`, so the off-screen export WebView gets the same receipt styling instead of silently falling back.
- Receipt width is reduced slightly and vertical padding increased slightly; the actual receipt design/assets/content are unchanged.
