# Nawab Oud Pro v2

A fully offline Android billing/POS project.

Included:
- Billing with preset attars and bottle options
- B2G1 offers
- Golden/Fancy bottle discounts
- ₹/% bill discounts
- Local bill history
- Daily/monthly sales reports
- Local stock tracking/adjustment
- JSON backup and restore
- Receipt generation/printing
- All product data bundled in the APK
- No network permission required

Build:
1. Open this project in Android Studio.
2. Let Gradle sync.
3. Build > Generate Bundle(s) / APK(s) > Generate APK(s).
4. Install app/build/outputs/apk/debug/app-debug.apk on Android.
