package com.nawaboud.pro

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.graphics.Picture
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.view.View
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var exportBusy = false

    inner class AndroidBridge {
        @JavascriptInterface fun printPage() = runOnUiThread {
            try {
                val pm = getSystemService(Context.PRINT_SERVICE) as android.print.PrintManager
                pm.print("Nawab Oud Receipt", web.createPrintDocumentAdapter("Nawab Oud Receipt"), android.print.PrintAttributes.Builder().build())
            } catch (e: Exception) { toast("Print failed: ${e.message}") }
        }
        @JavascriptInterface fun shareReceiptPdf() = runOnUiThread { exportReceipt(Mode.SHARE_PDF) }
        @JavascriptInterface fun saveReceiptPdf() = runOnUiThread { exportReceipt(Mode.SAVE_PDF) }
        @JavascriptInterface fun saveReceiptImage() = runOnUiThread { exportReceipt(Mode.SAVE_IMAGE) }
        @JavascriptInterface fun shareReceiptImage() = runOnUiThread { exportReceipt(Mode.SHARE_IMAGE) }
    }

    private enum class Mode { SHARE_PDF, SAVE_PDF, SAVE_IMAGE, SHARE_IMAGE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.useWideViewPort = false
        web.settings.loadWithOverviewMode = false
        web.settings.textZoom = 100
        web.setInitialScale(0)
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AndroidBridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    private fun exportReceipt(mode: Mode) {
        if (exportBusy) return
        exportBusy = true

        // IMPORTANT: render the approved receipt at its normal design width first,
        // then scale the COMPLETE receipt to the printer raster width.  Do NOT
        // reflow the HTML itself to 384 CSS px; that causes WebView clipping.
        val designW = 780
        val printerW = 384
        val viewportJs = """
            (function(){
              var m=document.querySelector('meta[name="viewport"]');
              if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}
              m.setAttribute('content','width=${designW},initial-scale=1,maximum-scale=1,user-scalable=no');
              document.documentElement.classList.add('export-mode');
              window.scrollTo(0,0);
            })();
        """.trimIndent()

        web.evaluateJavascript(viewportJs) {
            web.postDelayed({
                val oldW = web.width.coerceAtLeast(1)
                val oldH = web.height.coerceAtLeast(1)
                try {
                    web.measure(ViewMeasure.exact(designW), ViewMeasure.atMost(1000000))
                    web.layout(0, 0, designW, web.measuredHeight.coerceAtLeast(1))
                    web.scrollTo(0, 0)
                } catch (e: Exception) {
                    restoreWeb(oldW, oldH)
                    exportBusy = false
                    toast("Couldn't size bill: ${e.message}")
                    return@postDelayed
                }

                web.postDelayed({
                    web.evaluateJavascript(
                        """(function(){
                            var e=document.querySelector('.receipt.luxe');
                            if(!e) return '0';
                            var r=e.getBoundingClientRect();
                            return String(Math.ceil(r.height));
                        })()""".trimIndent()
                    ) { raw ->
                        try {
                            val designH = raw.trim('"').toDoubleOrNull()?.toInt()?.coerceAtLeast(1)
                                ?: web.measuredHeight.coerceAtLeast(1)

                            web.measure(ViewMeasure.exact(designW), ViewMeasure.exact(designH))
                            web.layout(0, 0, designW, designH)
                            web.scrollTo(0, 0)

                            // First capture the COMPLETE approved design at its natural
                            // width. Then resize the whole bitmap proportionally to 384 dots.
                            val source = Bitmap.createBitmap(designW, designH, Bitmap.Config.ARGB_8888)
                            Canvas(source).apply {
                                drawColor(Color.WHITE)
                                web.draw(this)
                            }

                            val outH = kotlin.math.ceil(designH * printerW.toFloat() / designW.toFloat())
                                .toInt().coerceAtLeast(1)
                            val bitmap = Bitmap.createScaledBitmap(source, printerW, outH, true)
                            source.recycle()

                            when (mode) {
                                Mode.SAVE_IMAGE, Mode.SHARE_IMAGE -> {
                                    val dir = File(cacheDir, "receipts").also { it.mkdirs() }
                                    val png = File(dir, "Nawab-Oud-Bill-${System.currentTimeMillis()}.png")
                                    FileOutputStream(png).use {
                                        check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) { "PNG encoding failed" }
                                    }
                                    if (mode == Mode.SAVE_IMAGE) saveToDownloads(png, "Nawab-Oud-Bill.png", "image/png")
                                    else shareFile(png, "image/png")
                                }
                                Mode.SHARE_PDF, Mode.SAVE_PDF -> {
                                    val pdfW = 164
                                    val pdfH = kotlin.math.ceil(bitmap.height * pdfW.toFloat() / bitmap.width.toFloat())
                                        .toInt().coerceAtLeast(1)
                                    val pdf = PdfDocument()
                                    val page = pdf.startPage(PdfDocument.PageInfo.Builder(pdfW, pdfH, 1).create())
                                    page.canvas.drawColor(Color.WHITE)
                                    page.canvas.drawBitmap(bitmap, null, android.graphics.Rect(0, 0, pdfW, pdfH), null)
                                    pdf.finishPage(page)
                                    val dir = File(cacheDir, "receipts").also { it.mkdirs() }
                                    val f = File(dir, "Nawab-Oud-Bill-${System.currentTimeMillis()}.pdf")
                                    FileOutputStream(f).use { pdf.writeTo(it) }
                                    pdf.close()
                                    if (mode == Mode.SAVE_PDF) saveToDownloads(f, "Nawab-Oud-Bill.pdf", "application/pdf")
                                    else shareFile(f, "application/pdf")
                                }
                            }
                            bitmap.recycle()
                        } catch (e: Exception) {
                            toast("Couldn't prepare bill: ${e.message}")
                        } finally {
                            restoreWeb(oldW, oldH)
                        }
                    }
                }, 350)
            }, 250)
        }
    }

    private object ViewMeasure {
        fun exact(v:Int)=android.view.View.MeasureSpec.makeMeasureSpec(v, android.view.View.MeasureSpec.EXACTLY)
        fun atMost(v:Int)=android.view.View.MeasureSpec.makeMeasureSpec(v, android.view.View.MeasureSpec.AT_MOST)
    }

    private fun restoreWeb(w:Int,h:Int){
        web.evaluateJavascript("""
            (function(){
              var m=document.querySelector('meta[name="viewport"]');
              if(m) m.setAttribute('content','width=device-width,initial-scale=1');
              document.documentElement.classList.remove('share-receipt-only');
              window.scrollTo(0,0);
            })();
        """.trimIndent(), null)
        web.measure(ViewMeasure.exact(w), ViewMeasure.exact(h)); web.layout(0,0,w,h)
        web.postDelayed({ exportBusy=false },300)
    }

    private fun shareFile(file: File, mime: String) {
        val uri = FileProvider.getUriForFile(this, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply { type=mime; putExtra(Intent.EXTRA_STREAM,uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        startActivity(Intent.createChooser(intent, "Share Nawab Oud bill"))
    }

    private fun saveToDownloads(file: File, name: String, mime: String) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Nawab Oud")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw Exception("Could not create download")
                contentResolver.openOutputStream(uri).use { out -> file.inputStream().use { it.copyTo(out!!) } }
                values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0); contentResolver.update(uri, values, null, null)
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).resolve("Nawab Oud"); dir.mkdirs()
                file.copyTo(dir.resolve(name), overwrite=true)
            }
            toast("Saved to Downloads/Nawab Oud")
        } catch (e: Exception) { toast("Save failed: ${e.message}") }
    }

    private fun toast(s:String)=runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
}
