# Nawab Oud Pro v3

Offline Android billing/POS app for Nawab Oud.

Included:
- Attar and perfume billing with the bundled product list
- Bottle/size options including Golden/Fancy 6ml
- Attar Buy 2 Get 1 (6ml) and perfume Buy 2 × 50ml Get 1 × 30ml offers
- ₹ amount and percentage discounts
- Golden/Fancy 6ml bottle discount
- Saved bill history with View/Print
- Daily/monthly sales reports
- Local stock tracking and adjustment
- JSON backup/restore
- Premium receipt layout with 58mm thermal-print CSS
- Android system print and receipt PDF sharing
- Nawab Oud launcher icon
- Duplicate-tap protection and one-way bill-finalization logic to prevent UI freezing/repeated bills
- AndroidX + BuildConfig enabled

The project is configured for GitHub Actions and Gradle 8.11.1.
