
/*
 Nawab Oud - requested UI enhancement helpers
 - Fragrance search/filter helper
 - Bill PDF/image export hooks
 This file is intentionally standalone so existing pricing/offer logic is untouched.
*/

(function () {
  'use strict';

  window.NawabOudEnhancements = {
    filterFragrances: function (items, query) {
      const q = String(query || '').trim().toLowerCase();
      if (!q) return Array.isArray(items) ? items : [];
      return (Array.isArray(items) ? items : []).filter(function (item) {
        const name = typeof item === 'string' ? item : (item && (item.name || item.title || ''));
        return String(name).toLowerCase().includes(q);
      });
    },

    async downloadBillImage(element, filename) {
      if (!element) throw new Error('Receipt element not found');
      if (!window.html2canvas) throw new Error('Image export library is not loaded');
      const canvas = await window.html2canvas(element, {
        backgroundColor: '#ffffff',
        scale: 3,
        useCORS: true
      });
      const link = document.createElement('a');
      link.download = filename || 'Nawab-Oud-Bill.png';
      link.href = canvas.toDataURL('image/png');
      link.click();
    }
  };
})();
