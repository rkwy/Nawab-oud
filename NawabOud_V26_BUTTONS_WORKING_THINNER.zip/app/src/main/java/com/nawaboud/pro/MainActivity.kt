package com.nawaboud.pro

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.ClipData
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.graphics.Picture
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.view.View
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var exportBusy = false

    inner class AndroidBridge {
        @JavascriptInterface public fun printPage() = runOnUiThread {
            // Do not send the WebView to Android's generic document/3x5 preview. That
            // path is what was introducing the wrong paper geometry. Print uses the same
            // exact 384-dot thermal PNG as Save Image and hands it to the printer app
            // (iPrint/Quick Share/etc.) through Android's standard image share contract.
            exportReceipt(Mode.PRINT_IMAGE)
        }
        @JavascriptInterface public fun shareReceiptPdf() = runOnUiThread { exportReceipt(Mode.SHARE_PDF) }
        @JavascriptInterface public fun saveReceiptPdf() = runOnUiThread { exportReceipt(Mode.SAVE_PDF) }
        @JavascriptInterface public fun saveReceiptImage() = runOnUiThread { exportReceipt(Mode.SAVE_IMAGE) }
        @JavascriptInterface public fun shareReceiptImage() = runOnUiThread { exportReceipt(Mode.SHARE_IMAGE) }
    }

    private enum class Mode { SHARE_PDF, SAVE_PDF, SAVE_IMAGE, SHARE_IMAGE, PRINT_IMAGE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.useWideViewPort = false
        web.settings.loadWithOverviewMode = false
        web.settings.textZoom = 100
        web.setInitialScale(0)
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AndroidBridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    private fun exportReceipt(mode: Mode) {
        if (exportBusy) return
        exportBusy = true

        // NEW EXPORT PIPELINE (V25): never resize or screenshot the on-screen WebView.
        // We clone only the generated receipt into a brand-new off-screen WebView,
        // give that WebView the exact export width, wait for its images/fonts, then
        // render that isolated WebView into a bitmap. This completely avoids the
        // phone viewport/screen-width clipping that broke previous exports.
        val targetW = if (mode == Mode.PRINT_IMAGE) 384 else 768
        val js = """(function(){
            var r=document.querySelector('.receipt.luxe');
            if(!r) return '';
            return r.outerHTML;
        })()""".trimIndent()

        web.evaluateJavascript(js) { encoded ->
            try {
                val receiptHtml = android.webkit.WebView(this).let { _ ->
                    org.json.JSONTokener(encoded).nextValue()?.toString() ?: ""
                }
                if (receiptHtml.isBlank()) throw Exception("Receipt is empty")
                renderFreshReceipt(receiptHtml, targetW, mode)
            } catch (e: Exception) {
                exportBusy = false
                toast("Couldn't prepare bill: ${e.message}")
            }
        }
    }

    private fun renderFreshReceipt(receiptHtml: String, targetW: Int, mode: Mode) {
        val css = try {
            assets.open("nawaboud_luxury_ui.css").bufferedReader().use { it.readText() } +
            assets.open("nawaboud_phone_ui_v8.css").bufferedReader().use { it.readText() }
        } catch (_: Exception) { "" }

        // Keep the approved receipt styling, but remove every screen/export rule.
        // The receipt is authored once at targetW; nothing is subsequently squeezed.
        val html = """<!doctype html><html><head>
<meta charset="utf-8">
<meta name="viewport" content="width=$targetW,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box}html,body{margin:0!important;padding:0!important;width:${targetW}px!important;background:#fff!important;overflow:hidden!important}
$css
.receipt-actions,.no-print{display:none!important}
.receipt.luxe{display:block!important;width:${targetW}px!important;min-width:${targetW}px!important;max-width:${targetW}px!important;min-height:0!important;height:auto!important;padding:0!important;background:#fff!important}
.receipt-border{width:${targetW}px!important;min-width:${targetW}px!important;max-width:${targetW}px!important;margin:0!important;box-sizing:border-box!important}
.rhead img,.receipt-footer-img{display:block!important;width:100%!important;max-width:none!important;height:auto!important}
</style></head><body>$receiptHtml</body></html>"""

        val exportWeb = WebView(this)
        exportWeb.settings.javaScriptEnabled = true
        exportWeb.settings.domStorageEnabled = true
        exportWeb.settings.allowFileAccess = true
        exportWeb.settings.allowContentAccess = true
        exportWeb.settings.useWideViewPort = false
        exportWeb.settings.loadWithOverviewMode = false
        exportWeb.setBackgroundColor(Color.WHITE)

        exportWeb.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                view.postDelayed({
                    try {
                        // Force the isolated export surface to its exact pixel width.
                        view.measure(ViewMeasure.exact(targetW), ViewMeasure.atMost(2000000))
                        view.layout(0, 0, targetW, view.measuredHeight.coerceAtLeast(1))
                        view.evaluateJavascript("""(function(){
                            return Math.max(document.documentElement.scrollHeight,document.body.scrollHeight,document.body.offsetHeight);
                        })()""".trimIndent()) { hRaw ->
                            val contentH = hRaw.toFloatOrNull()?.toInt()?.coerceAtLeast(1) ?: view.measuredHeight
                            view.measure(ViewMeasure.exact(targetW), ViewMeasure.exact(contentH))
                            view.layout(0, 0, targetW, contentH)
                            view.postDelayed({
                                try {
                                    val bitmap = Bitmap.createBitmap(targetW, contentH, Bitmap.Config.ARGB_8888)
                                    val canvas = Canvas(bitmap)
                                    canvas.drawColor(Color.WHITE)
                                    // This WebView has never been attached to the phone UI,
                                    // so draw() cannot be clipped by the device screen width.
                                    view.draw(canvas)
                                    exportBitmap(bitmap, mode)
                                } catch (e: Exception) {
                                    exportBusy = false
                                    toast("Export failed: ${e.message}")
                                } finally {
                                    view.destroy()
                                }
                            }, 250)
                        }
                    } catch (e: Exception) {
                        exportBusy = false
                        toast("Export sizing failed: ${e.message}")
                        view.destroy()
                    }
                }, 500)
            }
        }
        exportWeb.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
    }

    private fun exportBitmap(bitmap: Bitmap, mode: Mode) {
        try {
            val dir = File(cacheDir, "receipts").also { it.mkdirs() }
            when (mode) {
                Mode.SAVE_IMAGE, Mode.SHARE_IMAGE, Mode.PRINT_IMAGE -> {
                    val png = File(dir, "Nawab-Oud-Bill-${System.currentTimeMillis()}.png")
                    FileOutputStream(png).use { out ->
                        check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) { "PNG encoding failed" }
                    }
                    when (mode) {
                        Mode.SAVE_IMAGE -> saveToDownloads(png, "Nawab-Oud-Bill.png", "image/png")
                        Mode.SHARE_IMAGE -> shareFile(png, "image/png", "Share Nawab Oud bill")
                        Mode.PRINT_IMAGE -> shareFile(png, "image/png", "Print Nawab Oud bill")
                        else -> Unit
                    }
                }
                Mode.SAVE_PDF, Mode.SHARE_PDF -> {
                    // 58mm thermal paper = 164pt wide. Height follows the bitmap's
                    // exact aspect ratio, so the PDF can never distort or crop it.
                    val pdfW = 164
                    val pdfH = kotlin.math.max(1, kotlin.math.round(bitmap.height * pdfW.toFloat() / bitmap.width.toFloat()).toInt())
                    val pdf = PdfDocument()
                    val page = pdf.startPage(PdfDocument.PageInfo.Builder(pdfW, pdfH, 1).create())
                    page.canvas.drawColor(Color.WHITE)
                    page.canvas.drawBitmap(bitmap, null, android.graphics.Rect(0, 0, pdfW, pdfH), null)
                    pdf.finishPage(page)
                    val f = File(dir, "Nawab-Oud-Bill-${System.currentTimeMillis()}.pdf")
                    FileOutputStream(f).use { pdf.writeTo(it) }
                    pdf.close()
                    if (mode == Mode.SAVE_PDF) saveToDownloads(f, "Nawab-Oud-Bill.pdf", "application/pdf")
                    else shareFile(f, "application/pdf")
                }
            }
        } catch (e: Exception) {
            toast("Export failed: ${e.message}")
        } finally {
            bitmap.recycle()
            exportBusy = false
        }
    }

    private object ViewMeasure {
        fun exact(v:Int)=android.view.View.MeasureSpec.makeMeasureSpec(v, android.view.View.MeasureSpec.EXACTLY)
        fun atMost(v:Int)=android.view.View.MeasureSpec.makeMeasureSpec(v, android.view.View.MeasureSpec.AT_MOST)
    }

    private fun restoreWeb(w:Int,h:Int){
        web.evaluateJavascript("""
            (function(){
              var m=document.querySelector('meta[name="viewport"]');
              if(m) m.setAttribute('content','width=device-width,initial-scale=1');
              document.documentElement.classList.remove('share-receipt-only','export-mode','export-share','export-thermal');
              window.scrollTo(0,0);
            })();
        """.trimIndent(), null)
        web.measure(ViewMeasure.exact(w), ViewMeasure.exact(h)); web.layout(0,0,w,h)
        web.postDelayed({ exportBusy=false },300)
    }

    private fun shareFile(file: File, mime: String, chooserTitle: String = "Share Nawab Oud bill") {
        val uri = FileProvider.getUriForFile(this, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TITLE, "Nawab Oud Receipt")
            clipData = ClipData.newRawUri("Nawab Oud Receipt", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, chooserTitle))
    }

    private fun saveToDownloads(file: File, name: String, mime: String) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Nawab Oud")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw Exception("Could not create download")
                contentResolver.openOutputStream(uri).use { out -> file.inputStream().use { it.copyTo(out!!) } }
                values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0); contentResolver.update(uri, values, null, null)
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).resolve("Nawab Oud"); dir.mkdirs()
                file.copyTo(dir.resolve(name), overwrite=true)
            }
            toast("Saved to Downloads/Nawab Oud")
        } catch (e: Exception) { toast("Save failed: ${e.message}") }
    }

    private fun toast(s:String)=runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
}
