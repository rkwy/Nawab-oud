Requested additions for this project:
1. Manual universal 2+1: user selects the offer; it applies to any products, with the lowest-priced items free in groups of two paid/one free as specified.
2. Car section: all fragrances; Car Hanging ₹400; Car AC Vent ₹500.
3. Bill export: PDF and image download options.
4. Fragrance search.
5. Existing app icon, receipt design, prices and other logic should remain unchanged.

Note: this package contains a standalone enhancement helper. The existing project should wire its existing receipt element and fragrance list into these helpers rather than replacing unrelated application logic.
