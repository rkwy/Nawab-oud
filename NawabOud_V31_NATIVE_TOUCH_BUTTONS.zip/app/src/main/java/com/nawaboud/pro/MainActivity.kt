package com.nawaboud.pro

import android.app.Activity
import android.content.ClipData
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

/**
 * V30: the receipt action bar is rebuilt as a normal Android view in the Activity
 * layout. It is NOT overlaid on top of the WebView, and it does NOT use a custom
 * touch listener. This avoids the Android/WebView hit-testing problem that made
 * the previous generations look clickable but not respond.
 */
class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var root: LinearLayout
    private lateinit var nativeActions: LinearLayout
    private var exportBusy = false

    private enum class Mode { SAVE_PDF, SHARE_PDF, SAVE_IMAGE, SHARE_IMAGE, PRINT_IMAGE }

    inner class AndroidBridge {
        @JavascriptInterface fun showReceiptActions() = runOnUiThread {
            nativeActions.visibility = View.VISIBLE
            web.visibility = View.VISIBLE
        }

        @JavascriptInterface fun hideReceiptActions() = runOnUiThread {
            nativeActions.visibility = View.GONE
        }

        @JavascriptInterface fun saveReceiptPdf() = runOnUiThread { exportReceipt(Mode.SAVE_PDF) }
        @JavascriptInterface fun shareReceiptPdf() = runOnUiThread { exportReceipt(Mode.SHARE_PDF) }
        @JavascriptInterface fun saveReceiptImage() = runOnUiThread { exportReceipt(Mode.SAVE_IMAGE) }
        @JavascriptInterface fun shareReceiptImage() = runOnUiThread { exportReceipt(Mode.SHARE_IMAGE) }
        @JavascriptInterface fun printPage() = runOnUiThread { exportReceipt(Mode.PRINT_IMAGE) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        nativeActions = buildNativeActions().apply {
            visibility = View.GONE
        }
        root.addView(nativeActions, LinearLayout.LayoutParams(-1, -2))

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.useWideViewPort = false
            settings.loadWithOverviewMode = false
            settings.textZoom = 100
            setBackgroundColor(Color.WHITE)
            webViewClient = WebViewClient()
            addJavascriptInterface(AndroidBridge(), "Android")
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(Color.WHITE)
        minHeight = dp(52)
        minimumHeight = dp(52)
        setPadding(dp(4), 0, dp(4), 0)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(48, 35, 27))
            cornerRadius = dp(13).toFloat()
            setStroke(dp(1), Color.rgb(179, 138, 69))
        }
        elevation = dp(2).toFloat()
        isClickable = true
        isFocusable = true
        isEnabled = true
        // Handle the touch at the native Android view itself. Returning true on
        // ACTION_UP makes this independent of WebView/HTML hit-testing. The
        // normal click listener is kept as a fallback for accessibility/input
        // methods that dispatch a native click rather than a touch sequence.
        setOnTouchListener { v, event ->
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    v.alpha = 0.72f
                    true
                }
                android.view.MotionEvent.ACTION_UP -> {
                    v.alpha = 1f
                    v.performClick()
                    true
                }
                android.view.MotionEvent.ACTION_CANCEL -> {
                    v.alpha = 1f
                    true
                }
                else -> true
            }
        }
        setOnClickListener { action() }
    }

    private fun buildNativeActions(): LinearLayout {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.rgb(250, 247, 241))
            elevation = dp(6).toFloat()
            isClickable = true
            isFocusable = false
        }

        fun row(buttons: List<Button>): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            buttons.forEach { b ->
                addView(b, LinearLayout.LayoutParams(0, dp(54), 1f).apply {
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                })
            }
        }

        panel.addView(row(listOf(
            makeButton("← Back") { closeReceiptNative() },
            makeButton("📄 Save PDF") { exportReceipt(Mode.SAVE_PDF) },
            makeButton("📤 PDF") { exportReceipt(Mode.SHARE_PDF) }
        )))
        panel.addView(row(listOf(
            makeButton("🖼️ Save") { exportReceipt(Mode.SAVE_IMAGE) },
            makeButton("📤 Image") { exportReceipt(Mode.SHARE_IMAGE) },
            makeButton("🖨️ Print") { exportReceipt(Mode.PRINT_IMAGE) }
        )))
        return panel
    }

    private fun closeReceiptNative() {
        nativeActions.visibility = View.GONE
        web.evaluateJavascript("if(typeof closeReceipt==='function'){closeReceipt();}", null)
    }

    private fun exportReceipt(mode: Mode) {
        if (exportBusy) {
            toast("Please wait… preparing the bill")
            return
        }
        exportBusy = true
        val targetW = if (mode == Mode.PRINT_IMAGE) 384 else 768
        val js = """(function(){
            var r=document.querySelector('.receipt.luxe');
            return r ? r.outerHTML : '';
        })()""".trimIndent()

        web.evaluateJavascript(js) { encoded ->
            try {
                val receiptHtml = org.json.JSONTokener(encoded).nextValue()?.toString() ?: ""
                if (receiptHtml.isBlank()) throw IllegalStateException("Receipt is empty")
                renderFreshReceipt(receiptHtml, targetW, mode)
            } catch (e: Exception) {
                exportBusy = false
                toast("Couldn't prepare bill: ${e.message}")
            }
        }
    }

    private fun renderFreshReceipt(receiptHtml: String, targetW: Int, mode: Mode) {
        val css = try {
            assets.open("nawaboud_luxury_ui.css").bufferedReader().use { it.readText() } +
                assets.open("nawaboud_phone_ui_v8.css").bufferedReader().use { it.readText() }
        } catch (_: Exception) { "" }

        // Export is authored at a fixed pixel width and gets no later horizontal
        // squeeze. A tiny width reduction makes the receipt visually slimmer while
        // the natural content height makes it correspondingly a little longer.
        val exportWidth = if (mode == Mode.PRINT_IMAGE) 376 else targetW
        val html = """<!doctype html><html><head>
<meta charset="utf-8">
<meta name="viewport" content="width=$exportWidth,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box}
html,body{margin:0!important;padding:0!important;width:${exportWidth}px!important;background:#fff!important;overflow:hidden!important}
$css
.receipt-actions,.no-print{display:none!important}
.receipt.luxe{display:block!important;width:${exportWidth}px!important;min-width:${exportWidth}px!important;max-width:${exportWidth}px!important;min-height:0!important;height:auto!important;padding:0!important;background:#fff!important}
.receipt-border{width:${exportWidth}px!important;min-width:${exportWidth}px!important;max-width:${exportWidth}px!important;margin:0!important;box-sizing:border-box!important}
.rhead img,.receipt-footer-img{display:block!important;width:100%!important;max-width:none!important;height:auto!important}
</style></head><body>$receiptHtml</body></html>"""

        val exportWeb = WebView(this)
        exportWeb.settings.javaScriptEnabled = true
        exportWeb.settings.domStorageEnabled = true
        exportWeb.settings.allowFileAccess = true
        exportWeb.settings.allowContentAccess = true
        exportWeb.settings.useWideViewPort = false
        exportWeb.settings.loadWithOverviewMode = false
        exportWeb.setBackgroundColor(Color.WHITE)
        exportWeb.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                view.postDelayed({
                    try {
                        view.measure(exact(exportWidth), atMost(2000000))
                        view.layout(0, 0, exportWidth, view.measuredHeight.coerceAtLeast(1))
                        view.evaluateJavascript("Math.max(document.documentElement.scrollHeight,document.body.scrollHeight,document.body.offsetHeight)") { raw ->
                            val h = raw.toFloatOrNull()?.toInt()?.coerceAtLeast(1) ?: view.measuredHeight.coerceAtLeast(1)
                            view.measure(exact(exportWidth), exact(h))
                            view.layout(0, 0, exportWidth, h)
                            view.postDelayed({
                                try {
                                    val bitmap = Bitmap.createBitmap(exportWidth, h, Bitmap.Config.ARGB_8888)
                                    Canvas(bitmap).apply {
                                        drawColor(Color.WHITE)
                                        view.draw(this)
                                    }
                                    exportBitmap(bitmap, mode)
                                } catch (e: Exception) {
                                    exportBusy = false
                                    toast("Export failed: ${e.message}")
                                } finally {
                                    view.destroy()
                                }
                            }, 250)
                        }
                    } catch (e: Exception) {
                        exportBusy = false
                        toast("Export sizing failed: ${e.message}")
                        view.destroy()
                    }
                }, 500)
            }
        }
        exportWeb.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null)
    }

    private fun exportBitmap(bitmap: Bitmap, mode: Mode) {
        try {
            val dir = File(cacheDir, "receipts").also { it.mkdirs() }
            when (mode) {
                Mode.SAVE_IMAGE, Mode.SHARE_IMAGE, Mode.PRINT_IMAGE -> {
                    val png = File(dir, "Nawab-Oud-Bill-${System.currentTimeMillis()}.png")
                    FileOutputStream(png).use { out -> check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) }
                    when (mode) {
                        Mode.SAVE_IMAGE -> saveToDownloads(png, "Nawab-Oud-Bill.png", "image/png")
                        Mode.SHARE_IMAGE -> shareFile(png, "image/png", "Share Nawab Oud bill")
                        Mode.PRINT_IMAGE -> shareFile(png, "image/png", "Print Nawab Oud bill")
                        else -> Unit
                    }
                }
                Mode.SAVE_PDF, Mode.SHARE_PDF -> {
                    val pdfW = 164
                    val pdfH = kotlin.math.max(1, kotlin.math.round(bitmap.height * pdfW.toFloat() / bitmap.width.toFloat()).toInt())
                    val pdf = PdfDocument()
                    val page = pdf.startPage(PdfDocument.PageInfo.Builder(pdfW, pdfH, 1).create())
                    page.canvas.drawColor(Color.WHITE)
                    page.canvas.drawBitmap(bitmap, null, android.graphics.Rect(0, 0, pdfW, pdfH), null)
                    pdf.finishPage(page)
                    val f = File(dir, "Nawab-Oud-Bill-${System.currentTimeMillis()}.pdf")
                    FileOutputStream(f).use { pdf.writeTo(it) }
                    pdf.close()
                    if (mode == Mode.SAVE_PDF) saveToDownloads(f, "Nawab-Oud-Bill.pdf", "application/pdf")
                    else shareFile(f, "application/pdf")
                }
            }
        } catch (e: Exception) {
            toast("Export failed: ${e.message}")
        } finally {
            bitmap.recycle()
            exportBusy = false
        }
    }

    private fun exact(v: Int) = android.view.View.MeasureSpec.makeMeasureSpec(v, android.view.View.MeasureSpec.EXACTLY)
    private fun atMost(v: Int) = android.view.View.MeasureSpec.makeMeasureSpec(v, android.view.View.MeasureSpec.AT_MOST)

    private fun shareFile(file: File, mime: String, chooserTitle: String = "Share Nawab Oud bill") {
        val uri: Uri = FileProvider.getUriForFile(this, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TITLE, "Nawab Oud Receipt")
            clipData = ClipData.newRawUri("Nawab Oud Receipt", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, chooserTitle))
    }

    private fun saveToDownloads(file: File, name: String, mime: String) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Nawab Oud")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Could not create download")
                contentResolver.openOutputStream(uri).use { out -> file.inputStream().use { input -> input.copyTo(out!!) } }
                contentResolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).resolve("Nawab Oud")
                dir.mkdirs()
                file.copyTo(dir.resolve(name), overwrite = true)
            }
            toast("Saved to Downloads/Nawab Oud")
        } catch (e: Exception) {
            toast("Save failed: ${e.message}")
        }
    }

    private fun toast(s: String) = runOnUiThread {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }
}
