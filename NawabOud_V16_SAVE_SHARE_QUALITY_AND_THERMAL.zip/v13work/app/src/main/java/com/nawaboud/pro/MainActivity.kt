package com.nawaboud.pro

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.ClipData
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.graphics.Picture
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.view.View
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var exportBusy = false

    inner class AndroidBridge {
        @JavascriptInterface fun printPage() = runOnUiThread {
            // Do not send the WebView to Android's generic document/3x5 preview. That
            // path is what was introducing the wrong paper geometry. Print uses the same
            // exact 384-dot thermal PNG as Save Image and hands it to the printer app
            // (iPrint/Quick Share/etc.) through Android's standard image share contract.
            exportReceipt(Mode.PRINT_IMAGE)
        }
        @JavascriptInterface fun shareReceiptPdf() = runOnUiThread { exportReceipt(Mode.SHARE_PDF) }
        @JavascriptInterface fun saveReceiptPdf() = runOnUiThread { exportReceipt(Mode.SAVE_PDF) }
        @JavascriptInterface fun saveReceiptImage() = runOnUiThread { exportReceipt(Mode.SAVE_IMAGE) }
        @JavascriptInterface fun shareReceiptImage() = runOnUiThread { exportReceipt(Mode.SHARE_IMAGE) }
    }

    private enum class Mode { SHARE_PDF, SAVE_PDF, SAVE_IMAGE, SHARE_IMAGE, PRINT_IMAGE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.useWideViewPort = false
        web.settings.loadWithOverviewMode = false
        web.settings.textZoom = 100
        web.setInitialScale(0)
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(AndroidBridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    private fun exportReceipt(mode: Mode) {
        if (exportBusy) return
        exportBusy = true

        // Render the receipt at its real export canvas size. The previous build rendered
        // at 780px and then squeezed it down to 384px, which made the thermal text tiny
        // and blurry. Thermal output is now authored at 384px; phone sharing is authored
        // at 768px (2x) so the shared PNG is genuinely high resolution.
        // Keep one authoritative receipt layout at 768 CSS px (2x the 384-dot
        // thermal width).  We do NOT author the receipt at 384 and then enlarge it:
        // that is what made the saved image and PDF soft.  Thermal output is a
        // deliberate 384-dot derivative; phone/share/save use the full-resolution
        // 768-dot render.
        val printerW = 384
        val highResW = 768
        val designW = highResW
        val viewportJs = """
            (function(){
              var m=document.querySelector('meta[name="viewport"]');
              if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}
              m.setAttribute('content','width=${designW},initial-scale=1,maximum-scale=1,user-scalable=no');
              document.documentElement.classList.add('export-mode');
              document.documentElement.classList.toggle('export-share', ${if (mode == Mode.SHARE_IMAGE || mode == Mode.SAVE_IMAGE || mode == Mode.SHARE_PDF || mode == Mode.SAVE_PDF) 'true' else 'false'});
              document.documentElement.classList.toggle('export-thermal', ${if (mode == Mode.PRINT_IMAGE) 'true' else 'false'});
              window.scrollTo(0,0);
            })();
        """.trimIndent()

        web.evaluateJavascript(viewportJs) {
            web.postDelayed({
                val oldW = web.width.coerceAtLeast(1)
                val oldH = web.height.coerceAtLeast(1)
                try {
                    web.measure(ViewMeasure.exact(designW), ViewMeasure.atMost(1000000))
                    web.layout(0, 0, designW, web.measuredHeight.coerceAtLeast(1))
                    web.scrollTo(0, 0)
                } catch (e: Exception) {
                    restoreWeb(oldW, oldH)
                    exportBusy = false
                    toast("Couldn't size bill: ${e.message}")
                    return@postDelayed
                }

                web.postDelayed({
                    web.evaluateJavascript(
                        """(function(){
                            var e=document.querySelector('.receipt.luxe');
                            if(!e) return '0,0,0,0';
                            var r=e.getBoundingClientRect();
                            return [Math.round(r.left),Math.round(r.top),Math.ceil(r.width),Math.ceil(r.height)].join(',');
                        })()""".trimIndent()
                    ) { raw ->
                        try {
                            val bounds = raw.trim('"').split(',').map { it.toFloatOrNull() ?: 0f }
                            val left = bounds.getOrNull(0)?.toInt()?.coerceAtLeast(0) ?: 0
                            val top = bounds.getOrNull(1)?.toInt()?.coerceAtLeast(0) ?: 0
                            val receiptW = bounds.getOrNull(2)?.toInt()?.coerceAtLeast(1) ?: designW
                            val receiptH = bounds.getOrNull(3)?.toInt()?.coerceAtLeast(1) ?: web.measuredHeight

                            web.measure(ViewMeasure.exact(designW), ViewMeasure.exact(web.measuredHeight.coerceAtLeast(top + receiptH)))
                            web.layout(0, 0, designW, web.measuredHeight.coerceAtLeast(top + receiptH))
                            web.scrollTo(0, 0)

                            // Capture only the receipt rectangle. This prevents the old
                            // giant blank area and the right-side WebView/background strip.
                            val source = Bitmap.createBitmap(receiptW, receiptH, Bitmap.Config.ARGB_8888)
                            Canvas(source).apply {
                                drawColor(Color.WHITE)
                                save()
                                translate(-left.toFloat(), -top.toFloat())
                                web.draw(this)
                                restore()
                            }

                            when (mode) {
                                Mode.SAVE_IMAGE, Mode.SHARE_IMAGE, Mode.PRINT_IMAGE -> {
                                    // Save/share keep the high-resolution 768-dot render.
                                    // Only the actual thermal print path is reduced to the
                                    // printer's 384-dot head width.  This prevents a saved
                                    // phone image from being unnecessarily low-resolution.
                                    val targetW = if (mode == Mode.PRINT_IMAGE) printerW else highResW
                                    val outH = kotlin.math.ceil(receiptH * targetW.toFloat() / receiptW.toFloat())
                                        .toInt().coerceAtLeast(1)
                                    val bitmap = if (targetW == receiptW) source.copy(Bitmap.Config.ARGB_8888, false)
                                    else Bitmap.createScaledBitmap(source, targetW, outH, true)
                                    val dir = File(cacheDir, "receipts").also { it.mkdirs() }
                                    val png = File(dir, "Nawab-Oud-Bill-${System.currentTimeMillis()}.png")
                                    FileOutputStream(png).use {
                                        check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) { "PNG encoding failed" }
                                    }
                                    bitmap.recycle()
                                    when (mode) {
                                        Mode.SAVE_IMAGE -> saveToDownloads(png, "Nawab-Oud-Bill.png", "image/png")
                                        Mode.SHARE_IMAGE -> shareFile(png, "image/png", "Share Nawab Oud bill")
                                        Mode.PRINT_IMAGE -> shareFile(png, "image/png", "Print Nawab Oud bill")
                                        else -> Unit
                                    }
                                }
                                Mode.SHARE_PDF, Mode.SAVE_PDF -> {
                                    // 58mm = 164 points. Use the high-resolution source and
                                    // draw it onto a page with the exact receipt aspect ratio.
                                    // The page contains ONLY the receipt: no WebView background,
                                    // no fixed 3x5 card and no right-side strip.
                                    val pdfW = 164
                                    val pdfH = kotlin.math.ceil(receiptH * pdfW.toFloat() / receiptW.toFloat())
                                        .toInt().coerceAtLeast(1)
                                    val pdf = PdfDocument()
                                    val page = pdf.startPage(PdfDocument.PageInfo.Builder(pdfW, pdfH, 1).create())
                                    page.canvas.drawColor(Color.WHITE)
                                    page.canvas.drawBitmap(source, null, android.graphics.Rect(0, 0, pdfW, pdfH), null)
                                    pdf.finishPage(page)
                                    val dir = File(cacheDir, "receipts").also { it.mkdirs() }
                                    val f = File(dir, "Nawab-Oud-Bill-${System.currentTimeMillis()}.pdf")
                                    FileOutputStream(f).use { pdf.writeTo(it) }
                                    pdf.close()
                                    if (mode == Mode.SAVE_PDF) saveToDownloads(f, "Nawab-Oud-Bill.pdf", "application/pdf")
                                    else shareFile(f, "application/pdf")
                                }
                            }
                            source.recycle()
                        } catch (e: Exception) {
                            toast("Couldn't prepare bill: ${e.message}")
                        } finally {
                            restoreWeb(oldW, oldH)
                        }
                    }
                }, 350)
            }, 250)
        }
    }

    private object ViewMeasure {
        fun exact(v:Int)=android.view.View.MeasureSpec.makeMeasureSpec(v, android.view.View.MeasureSpec.EXACTLY)
        fun atMost(v:Int)=android.view.View.MeasureSpec.makeMeasureSpec(v, android.view.View.MeasureSpec.AT_MOST)
    }

    private fun restoreWeb(w:Int,h:Int){
        web.evaluateJavascript("""
            (function(){
              var m=document.querySelector('meta[name="viewport"]');
              if(m) m.setAttribute('content','width=device-width,initial-scale=1');
              document.documentElement.classList.remove('share-receipt-only','export-mode','export-share','export-thermal');
              window.scrollTo(0,0);
            })();
        """.trimIndent(), null)
        web.measure(ViewMeasure.exact(w), ViewMeasure.exact(h)); web.layout(0,0,w,h)
        web.postDelayed({ exportBusy=false },300)
    }

    private fun shareFile(file: File, mime: String, chooserTitle: String = "Share Nawab Oud bill") {
        val uri = FileProvider.getUriForFile(this, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TITLE, "Nawab Oud Receipt")
            clipData = ClipData.newRawUri("Nawab Oud Receipt", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, chooserTitle))
    }

    private fun saveToDownloads(file: File, name: String, mime: String) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Nawab Oud")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw Exception("Could not create download")
                contentResolver.openOutputStream(uri).use { out -> file.inputStream().use { it.copyTo(out!!) } }
                values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0); contentResolver.update(uri, values, null, null)
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).resolve("Nawab Oud"); dir.mkdirs()
                file.copyTo(dir.resolve(name), overwrite=true)
            }
            toast("Saved to Downloads/Nawab Oud")
        } catch (e: Exception) { toast("Save failed: ${e.message}") }
    }

    private fun toast(s:String)=runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
}
